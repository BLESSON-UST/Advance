package com.example.Springbootkuberneties;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootKubernetiesApplicationTests {

	@Test
	void contextLoads() {
	}

}
