package com.example.Springbootkuberneties;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootKubernetiesApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootKubernetiesApplication.class, args);
	}

}
